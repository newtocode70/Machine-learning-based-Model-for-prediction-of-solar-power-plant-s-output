 
import streamlit as st
import numpy as np

st.set_page_config(page_title="Solar Power Predictor", layout="centered")

st.title("☀️ Solar Power Plant Output Predictor")
st.write("Predict Plant AC Power Output (kW) using **Public Weather Data (Set B)**.")

# Load saved weights
try:
    weights = np.load("results/model_weights.npz")
    theta_B = weights["theta_B"]
    mean_B = weights["mean_B"]
    std_B = weights["std_B"]
except Exception:
    st.error("Model weights file not found! Please run train_eval.py first.")
    st.stop()

st.sidebar.header("Input Features")
hour = st.sidebar.slider("Hour of Day (0 - 23)", 0, 23, 12)
sw_radiation = st.sidebar.number_input("Shortwave Radiation (W/m²)", min_value=0.0, max_value=1200.0, value=500.0)
temp2m = st.sidebar.number_input("Temperature 2m (°C)", min_value=0.0, max_value=60.0, value=30.0)
cloud_cover = st.sidebar.number_input("Cloud Cover (%)", min_value=0.0, max_value=100.0, value=20.0)

if st.button("Predict AC Power"):
    # Feature Engineering (Cyclic Hour)
    sin_hour = np.sin(2 * np.pi * hour / 24)
    cos_hour = np.cos(2 * np.pi * hour / 24)
    
    # Scale Inputs
    raw_inputs = np.array([sw_radiation, temp2m, cloud_cover, sin_hour, cos_hour])
    scaled_inputs = (raw_inputs - mean_B) / std_B
    
    # Add Intercept
    final_inputs = np.insert(scaled_inputs, 0, 1.0)
    
    # Hypothesis Prediction & Clipping
    predicted_power = np.dot(final_inputs, theta_B)
    predicted_power = max(0.0, float(predicted_power))
    
    st.markdown("---")
    st.metric(label="Predicted AC Power Output", value=f"{predicted_power:.2f} kW")