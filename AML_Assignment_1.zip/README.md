# Applied Machine Learning - Assignment 1
**Predicting Solar Power Plant Output from Weather**

## 📌 Overview
This project predicts Solar Plant AC power output using Linear Regression implemented entirely from scratch using **NumPy** (without using any ML libraries like scikit-learn). It compares on-site sensor data (Set A) against public weather data from Open-Meteo (Set B).

## 📁 Repository Structure
├── app/
│   └── app.py                  # Streamlit Web Front-End
├── data/                       # Kaggle & Open-Meteo CSV files
├── results/                    # Figures, saved model weights, and analysis
├── src/
│   ├── load_data.py            # Data Loader
│   ├── prepare.py              # Data Preparation & Hourly Resampling
│   ├── eda.py                  # Exploratory Plots
│   ├── fetch_weather.py        # Open-Meteo API Fetching
│   ├── regression.py           # Custom Normal Eq, Batch GD, and SGD Solvers
│   └── train_eval.py           # Model Training and Evaluation Pipeline
├── README.md                   # Setup and Run Instructions


## 🚀 How to Run

### 1. Install Dependencies
```bash
pip install numpy pandas matplotlib requests streamlit