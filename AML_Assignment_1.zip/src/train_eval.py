import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# ============================================================
# LOAD DATA
# ============================================================

df = pd.read_csv("data/plant1_merged.csv")
df["datetime"] = pd.to_datetime(df["datetime"])


# ============================================================
# TRAIN / TEST SPLIT
# ============================================================

train = df[
    (df["datetime"] >= "2020-05-15") &
    (df["datetime"] < "2020-06-11")
].copy()

test = df[
    (df["datetime"] >= "2020-06-11") &
    (df["datetime"] < "2020-06-18")
].copy()


print("Training rows:", len(train))
print("Testing rows:", len(test))

print("\nTraining date range:")
print(train["datetime"].min(), "to", train["datetime"].max())

print("\nTesting date range:")
print(test["datetime"].min(), "to", test["datetime"].max())


# ============================================================
# HOUR FEATURES
# ============================================================

train["hour"] = train["datetime"].dt.hour
test["hour"] = test["datetime"].dt.hour

train["sin_hour"] = np.sin(2 * np.pi * train["hour"] / 24)
train["cos_hour"] = np.cos(2 * np.pi * train["hour"] / 24)

test["sin_hour"] = np.sin(2 * np.pi * test["hour"] / 24)
test["cos_hour"] = np.cos(2 * np.pi * test["hour"] / 24)


print("\nHour features:")
print(train[["hour", "sin_hour", "cos_hour"]].head())


# ============================================================
# FEATURE SET A
# ============================================================

X_train_A = train[
    ["irradiation", "module_temp", "ambient_temp", "sin_hour", "cos_hour"]
].values

X_test_A = test[
    ["irradiation", "module_temp", "ambient_temp", "sin_hour", "cos_hour"]
].values


# ============================================================
# FEATURE SET B
# ============================================================

X_train_B = train[
    ["public_sw_radiation", "public_temp2m", "cloud_cover", "sin_hour", "cos_hour"]
].values

X_test_B = test[
    ["public_sw_radiation", "public_temp2m", "cloud_cover", "sin_hour", "cos_hour"]
].values


# ============================================================
# TARGET
# ============================================================

y_train = train["ac_power"].values
y_test = test["ac_power"].values


print("\nFeature Set A shape:")
print("Train:", X_train_A.shape)
print("Test:", X_test_A.shape)

print("\nFeature Set B shape:")
print("Train:", X_train_B.shape)
print("Test:", X_test_B.shape)

print("\nTarget shape:")
print("Train:", y_train.shape)
print("Test:", y_test.shape)


# ============================================================
# FEATURE SCALING
# TRAINING DATA ONLY
# ============================================================

mean_A = X_train_A.mean(axis=0)
std_A = X_train_A.std(axis=0)

mean_B = X_train_B.mean(axis=0)
std_B = X_train_B.std(axis=0)

std_A[std_A == 0] = 1
std_B[std_B == 0] = 1

X_train_A_scaled = (X_train_A - mean_A) / std_A
X_test_A_scaled = (X_test_A - mean_A) / std_A

X_train_B_scaled = (X_train_B - mean_B) / std_B
X_test_B_scaled = (X_test_B - mean_B) / std_B


print("\nScaled Feature Set A - first 3 rows:")
print(X_train_A_scaled[:3])

print("\nScaled Feature Set B - first 3 rows:")
print(X_train_B_scaled[:3])


# ============================================================
# ADD INTERCEPT
# ============================================================

X_train_A_final = np.c_[np.ones(len(X_train_A_scaled)), X_train_A_scaled]
X_test_A_final = np.c_[np.ones(len(X_test_A_scaled)), X_test_A_scaled]

X_train_B_final = np.c_[np.ones(len(X_train_B_scaled)), X_train_B_scaled]
X_test_B_final = np.c_[np.ones(len(X_test_B_scaled)), X_test_B_scaled]


print("\nFinal Feature Set A shape:")
print("Train:", X_train_A_final.shape)
print("Test:", X_test_A_final.shape)

print("\nFinal Feature Set B shape:")
print("Train:", X_train_B_final.shape)
print("Test:", X_test_B_final.shape)


print("\nFirst row Set A:")
print(X_train_A_final[0])


# ============================================================
# HYPOTHESIS
# ============================================================

def hypothesis(X, theta):
    return X @ theta


# ============================================================
# NORMAL EQUATION
# ============================================================

def normal_equation(X, y):
    theta = np.linalg.inv(X.T @ X) @ X.T @ y
    return theta


theta_A_NE = normal_equation(X_train_A_final, y_train)
theta_B_NE = normal_equation(X_train_B_final, y_train)


print("\nNormal Equation - Set A theta:")
print(theta_A_NE)

print("\nNormal Equation - Set B theta:")
print(theta_B_NE)


# ============================================================
# TRAINING PREDICTIONS
# ============================================================

pred_A_NE = hypothesis(X_train_A_final, theta_A_NE)
pred_B_NE = hypothesis(X_train_B_final, theta_B_NE)


print("\nTraining predictions - Set A:")
print(pred_A_NE[:5])

print("\nTraining predictions - Set B:")
print(pred_B_NE[:5])


# ============================================================
# COST FUNCTION
# ============================================================

def compute_cost(X, y, theta):
    m = len(y)
    predictions = hypothesis(X, theta)
    error = predictions - y
    J = (1 / (2 * m)) * np.sum(error ** 2)
    return J


cost_A_NE = compute_cost(
    X_train_A_final,
    y_train,
    theta_A_NE
)

cost_B_NE = compute_cost(
    X_train_B_final,
    y_train,
    theta_B_NE
)


print("\nNormal Equation Training Cost:")
print("Set A:", cost_A_NE)
print("Set B:", cost_B_NE)


# ============================================================
# BATCH GRADIENT DESCENT
# ============================================================

def batch_gradient_descent(X, y, alpha, iterations):

    m = len(y)

    theta = np.zeros(X.shape[1])

    J_history = []

    for i in range(iterations):

        predictions = hypothesis(X, theta)

        error = predictions - y

        gradient = (1 / m) * (X.T @ error)

        theta = theta - alpha * gradient

        J_history.append(
            compute_cost(X, y, theta)
        )

    return theta, J_history


# ============================================================
# LEARNING RATE COMPARISON
# ============================================================

alphas = [1e-5, 1e-4, 1e-3]


plt.figure(figsize=(10, 6))


for alpha in alphas:

    theta, J_history = batch_gradient_descent(
        X_train_A_final,
        y_train,
        alpha,
        500
    )

    print("\nBatch GD - Set A")
    print("Alpha:", alpha)
    print("First Cost:", J_history[0])
    print("Last Cost:", J_history[-1])

    plt.plot(
        range(1, 501),
        J_history,
        label=f"alpha = {alpha}"
    )


plt.xlabel("Iteration")
plt.ylabel("Cost J(theta)")
plt.title(
    "Batch Gradient Descent Learning Rate Comparison - Set A"
)
plt.legend()
plt.grid(True)

plt.savefig(
    "results/batch_gd_learning_rates.png"
)

plt.show()


# ============================================================
# COST DECREASE VERIFICATION
# ============================================================

theta_check, J_check = batch_gradient_descent(
    X_train_A_final,
    y_train,
    0.001,
    500
)

cost_differences = np.diff(J_check)

print("\nBatch GD Cost Decrease Check")
print("Alpha: 0.001")
print("Number of iterations:", len(J_check))
print("Largest cost change:", np.max(cost_differences))
print("Number of increases:", np.sum(cost_differences > 0))
print("Number of equal values:", np.sum(cost_differences == 0))

# ============================================================
# BATCH GD CONVERGENCE PROGRESS
# ============================================================

iteration_values = [5000, 10000, 25000, 50000, 100000]

print("\nBatch GD Convergence Progress")

for iterations in iteration_values:
    theta_test, J_test = batch_gradient_descent(
        X_train_A_final,
        y_train,
        0.01,
        iterations
    )
    difference = np.abs(theta_test - theta_A_NE)
    
    print("\nIterations:", iterations)
    print("Final Cost:", J_test[-1])
    print("Maximum absolute theta difference:", np.max(difference))

# ============================================================
# STOCHASTIC GRADIENT DESCENT (SGD)
# ============================================================

def fit_sgd(X, y, alpha, epochs):
    m = len(y)
    theta = np.zeros(X.shape[1])
    J_history = []
    
    np.random.seed(42) # Repeatability ke liye
    
    for epoch in range(epochs):
        indices = np.random.permutation(m)
        X_shuffled = X[indices]
        y_shuffled = y[indices]
        
        for i in range(m):
            xi = X_shuffled[i:i+1]
            yi = y_shuffled[i]
            
            prediction = hypothesis(xi, theta)
            error = prediction - yi
            
            # SGD Single sample update
            gradient = xi.T.flatten() * error
            theta = theta - alpha * gradient
            
        J_history.append(compute_cost(X, y, theta))
        
    return theta, J_history


# ============================================================
# SGD LEARNING RATE COMPARISON (TASK 4.7)
# ============================================================

alphas_sgd = [1e-4, 1e-3, 1e-2]

plt.figure(figsize=(10, 6))

for alpha in alphas_sgd:
    theta_sgd_temp, J_sgd_hist = fit_sgd(
        X_train_A_final,
        y_train,
        alpha,
        50
    )
    
    print("\nSGD - Set A")
    print("Alpha:", alpha)
    print("First Cost:", J_sgd_hist[0])
    print("Last Cost:", J_sgd_hist[-1])
    
    plt.plot(
        range(1, 51),
        J_sgd_hist,
        label=f"alpha = {alpha}"
    )

plt.xlabel("Epoch")
plt.ylabel("Cost J(theta)")
plt.title("Stochastic Gradient Descent Learning Rate Comparison - Set A")
plt.legend()
plt.grid(True)

plt.savefig("results/sgd_learning_rates.png")
plt.close()

print("\nSaved SGD Learning Rates plot to results/sgd_learning_rates.png")

# ============================================================
# TASK 4.8 - 4.10: FINAL MODEL FITTING & RMSE EVALUATION
# ============================================================

def compute_rmse(y_true, y_pred):
    return np.sqrt(np.mean((y_true - y_pred) ** 2))

# Optimal Hyperparameters
alpha_bgd = 0.01
iters_bgd = 100000

alpha_sgd = 0.01
epochs_sgd = 100

# 1. Fit Set A
theta_A_NE = normal_equation(X_train_A_final, y_train)
theta_A_BGD, _ = batch_gradient_descent(X_train_A_final, y_train, alpha_bgd, iters_bgd)
theta_A_SGD, _ = fit_sgd(X_train_A_final, y_train, alpha_sgd, epochs_sgd)

# 2. Fit Set B
theta_B_NE = normal_equation(X_train_B_final, y_train)
theta_B_BGD, _ = batch_gradient_descent(X_train_B_final, y_train, alpha_bgd, iters_bgd)
theta_B_SGD, _ = fit_sgd(X_train_B_final, y_train, alpha_sgd, epochs_sgd)

# Daytime Mask for Test Set (irradiation > 0)
daytime_mask = test["irradiation"].values > 0

def evaluate_model(X_test, y_test, theta):
    preds = hypothesis(X_test, theta)
    preds_clipped = np.clip(preds, 0, None) # Clip negative predictions
    
    rmse_all = compute_rmse(y_test, preds_clipped)
    rmse_day = compute_rmse(y_test[daytime_mask], preds_clipped[daytime_mask])
    return rmse_all, rmse_day

print("\n" + "="*60)
print("TABLE 3: LEARNED THETA COMPARISON (SET A)")
print("="*60)

theta_comparison = pd.DataFrame({
    "Feature": ["Intercept (θ0)", "Irradiation (θ1)", "Module Temp (θ2)", "Ambient Temp (θ3)", "sin_hour (θ4)", "cos_hour (θ5)"],
    "Normal Eq": theta_A_NE,
    "Batch GD": theta_A_BGD,
    "SGD": theta_A_SGD,
    "|BGD - Normal|": np.abs(theta_A_BGD - theta_A_NE)
})
print(theta_comparison.to_string(index=False))

print("\n" + "="*60)
print("TABLE 2: TEST RMSE (kW)")
print("="*60)

rmse_data = []

solvers_A = [("Normal Equation", theta_A_NE), ("Batch GD", theta_A_BGD), ("SGD", theta_A_SGD)]
solvers_B = [("Normal Equation", theta_B_NE), ("Batch GD", theta_B_BGD), ("SGD", theta_B_SGD)]

for name, theta in solvers_A:
    all_h, day_h = evaluate_model(X_test_A_final, y_test, theta)
    rmse_data.append({"Feature Set": "Set A", "Solver": name, "All Hours RMSE": all_h, "Daytime RMSE": day_h})

for name, theta in solvers_B:
    all_h, day_h = evaluate_model(X_test_B_final, y_test, theta)
    rmse_data.append({"Feature Set": "Set B", "Solver": name, "All Hours RMSE": all_h, "Daytime RMSE": day_h})

rmse_df = pd.DataFrame(rmse_data)
print(rmse_df.to_string(index=False))

# Save learned Set B model weights for Streamlit Frontend (Task 6)
np.savez("results/model_weights.npz", theta_B=theta_B_NE, mean_B=mean_B, std_B=std_B)
print("\nModel weights successfully saved to results/model_weights.npz")