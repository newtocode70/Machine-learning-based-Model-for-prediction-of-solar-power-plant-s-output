import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/plant1_hourly.csv")

plt.figure(figsize=(8, 5))
plt.scatter(df["irradiation"], df["ac_power"], s=10)
plt.xlabel("Irradiation (kW/m²)")
plt.ylabel("AC Power (kW)")
plt.title("AC Power vs Irradiation")
plt.grid(True)
plt.savefig("results/ac_power_vs_irradiation.png", dpi=300)
plt.show()

plt.figure(figsize=(8, 5))
plt.scatter(
    df["ambient_temp"],
    df["module_temp"],
    c=df["irradiation"],
    s=10
)
plt.xlabel("Ambient Temperature (°C)")
plt.ylabel("Module Temperature (°C)")
plt.title("Module Temperature vs Ambient Temperature")
plt.colorbar(label="Irradiation (kW/m²)")
plt.grid(True)
plt.savefig("results/module_vs_ambient_temp.png", dpi=300)
plt.show()

plt.figure(figsize=(8, 5))
plt.scatter(
    df["dc_power"],
    df["ac_power"],
    s=10
)
plt.xlabel("DC Power (kW)")
plt.ylabel("AC Power (kW)")
plt.title("AC Power vs DC Power")
plt.grid(True)
plt.savefig("results/ac_vs_dc_power.png", dpi=300)
plt.show()

df["hour"] = pd.to_datetime(df["datetime"]).dt.hour

hourly_ac = df.groupby("hour")["ac_power"].mean()

plt.figure(figsize=(8, 5))
plt.plot(hourly_ac.index, hourly_ac.values, marker="o")
plt.xlabel("Hour of Day")
plt.ylabel("Average AC Power (kW)")
plt.title("Average AC Power by Hour of Day")
plt.xticks(range(24))
plt.grid(True)
plt.savefig("results/average_ac_by_hour.png", dpi=300)
plt.show()

print("\nObservations:")

print("1. AC power generally increases as irradiation increases, which agrees with the expected behavior of a solar power plant.")

print("2. Module temperature generally increases with ambient temperature and higher irradiation, because solar radiation heats the PV modules.")

print("3. AC and DC power show a strong positive relationship. AC power is lower than DC power because of conversion and other system losses.")

print("4. Average AC power is close to zero during night hours, rises during the morning, reaches its maximum around midday, and decreases again toward evening.")