import pandas as pd
from load_data import load_raw

raw = load_raw()

gen = raw["gen1"]
sensor = raw["sensor1"]

print("Generation DATE_TIME before conversion:")
print(gen["DATE_TIME"].head())

print("\nSensor DATE_TIME before conversion:")
print(sensor["DATE_TIME"].head())

# Convert string timestamps to datetime objects
gen["datetime"] = pd.to_datetime(
    gen["DATE_TIME"],
    format="%d-%m-%Y %H:%M"
)

sensor["datetime"] = pd.to_datetime(
    sensor["DATE_TIME"],
    format="%Y-%m-%d %H:%M:%S"
)

print("\nGeneration first timestamp:", gen["datetime"].min())
print("Generation last timestamp:", gen["datetime"].max())

print("Sensor first timestamp:", sensor["datetime"].min())
print("Sensor last timestamp:", sensor["datetime"].max())

# Sum across all 22 inverters at each timestamp
gen_hourly = gen.groupby("datetime").agg({
    "AC_POWER": "sum",
    "DC_POWER": "sum"
}).reset_index()

print("\nPlant-level generation:")
print(gen_hourly.head())

print("\nGeneration rows after grouping:", len(gen_hourly))

sensor_columns = [
    "datetime",
    "AMBIENT_TEMPERATURE",
    "MODULE_TEMPERATURE",
    "IRRADIATION"
]

sensor_clean = sensor[sensor_columns]

# Merge plant-level power with sensor data
merged = pd.merge(
    gen_hourly,
    sensor_clean,
    on="datetime",
    how="outer",
    indicator=True
)

print("\nMerge result:")
print(merged["_merge"].value_counts())

print("\nRows in only one file:")
print(merged[merged["_merge"] != "both"][["datetime", "_merge"]].head(20))

# Resample to hourly means
hourly = merged.drop(columns="_merge")
hourly = hourly.set_index("datetime").resample("1h").mean().reset_index()

hourly = hourly.rename(columns={
    "AC_POWER": "ac_power",
    "DC_POWER": "dc_power",
    "AMBIENT_TEMPERATURE": "ambient_temp",
    "MODULE_TEMPERATURE": "module_temp",
    "IRRADIATION": "irradiation"
})

# --- ADDED: Convert kW to MW (or divide by 1000 to fix scale issue) ---
hourly["ac_power"] = hourly["ac_power"] / 1000.0
hourly["dc_power"] = hourly["dc_power"] / 1000.0
# ----------------------------------------------------------------------

print("\nHourly data:")
print(hourly.head())

print("\nHourly rows:", len(hourly))
print("\nMissing values:")
print(hourly.isna().sum())

missing_rows = hourly.isna().any(axis=1).sum()
print("\nHourly rows with missing values:", missing_rows)

# Drop missing values and save
hourly_clean = hourly.dropna().copy()
print("Hourly rows after removing missing values:", len(hourly_clean))

hourly_clean.to_csv("data/plant1_hourly.csv", index=False)
print("Final file saved: data/plant1_hourly.csv")